﻿using UnityEngine;
using System.Collections;

public class MinusCoin : MonoBehaviour
{
    [SerializeField] private float turnSpeed = 90f;
    public AudioSource crashSoundSource;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.GetComponent<Obstacle>() != null || !other.CompareTag("Player"))
        {
            return;
        }

        if (crashSoundSource != null && crashSoundSource.clip != null)
        {
            DisableObject();
            crashSoundSource.Play();
            StartCoroutine(DestroyAfterSound(crashSoundSource.clip.length));
        }
        else
        {
            Debug.LogError("CrashSoundSource or its clip is missing on MinusCoin!");
            DestroyImmediate(gameObject); // Eğer ses dosyası yoksa, objeyi hemen yok et
        }

        // Diğer işlevler
        GameManager.inst.IncrementFireCount();
    }

    private IEnumerator DestroyAfterSound(float delay)
    {
        yield return new WaitForSeconds(delay);  // Ses dosyasının uzunluğu kadar bekler
        Debug.Log("Destroying object now");
        Destroy(gameObject);
    }

    private void DisableObject()
    {
        // Collider ve Renderer'ı devre dışı bırak
        var collider = GetComponent<Collider>();
        if (collider) collider.enabled = false;
        var renderer = GetComponent<Renderer>();
        if (renderer) renderer.enabled = false;
    }

    private void Update()
    {
        transform.Rotate(0, 0, turnSpeed * Time.deltaTime);
    }
}
