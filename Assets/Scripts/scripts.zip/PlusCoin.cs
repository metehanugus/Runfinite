﻿using UnityEngine;
using System.Collections;

public class PlusCoin : MonoBehaviour
{
    [SerializeField] float turnSpeed = 90f;
    public AudioSource crashSoundSource;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.GetComponent<Obstacle>() != null)
        {
            Destroy(gameObject);
            return;
        }
        if (other.gameObject.CompareTag("Player"))
        {
            if (crashSoundSource != null && crashSoundSource.clip != null)
            {
                StartCoroutine(PlaySoundAndDestroy(crashSoundSource.clip.length));
            }
            else
            {
                Debug.LogError("CrashSoundSource or its clip is missing on PlusCoin!");
                Destroy(gameObject); // AudioSource yoksa, hemen yok et
            }

            // Diğer işlevler
            GameManager.inst.IncrementScore();
            GameManager.inst.IncrementIceCount();
        }
    }

    private IEnumerator PlaySoundAndDestroy(float delay)
    {
        crashSoundSource.Play();
        yield return new WaitForSeconds(delay); // Ses bitene kadar bekle
        Destroy(gameObject);
    }

    private void Update()
    {
        transform.Rotate(0, 0, turnSpeed * Time.deltaTime);
    }
}
