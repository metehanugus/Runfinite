﻿using UnityEngine;
using System.Collections;

public class PlusTime : MonoBehaviour
{
    [SerializeField] int moneyAmount = 10; // Eklenecek para
    public AudioSource crashSoundSource;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.GetComponent<Obstacle>() != null)
        {
            Destroy(gameObject);
            return;
        }
        if (other.gameObject.CompareTag("Player"))
        {
            if (crashSoundSource != null && crashSoundSource.clip != null)
            {
                StartCoroutine(PlaySoundAndDestroy(crashSoundSource.clip.length));
            }
            else
            {
                Debug.LogError("CrashSoundSource or its clip is missing on PlusTime!");
                Destroy(gameObject); // AudioSource yoksa, hemen yok et
            }

            // Diğer işlevler
            GameManager.inst.AddTime();
            GameManager.inst.AddMoney(moneyAmount);
        }
    }

    private IEnumerator PlaySoundAndDestroy(float delay)
    {
        crashSoundSource.Play();
        yield return new WaitForSeconds(delay); // Ses bitene kadar bekle
        Destroy(gameObject);
    }
}
